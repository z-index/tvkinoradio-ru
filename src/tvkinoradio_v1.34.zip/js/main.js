var MainJsClass = function () {
	var scope = this;

	this.customDatepicker = function () {
		if($('.custom-datepicker').length){

			$(".custom-datepicker", "").datepicker({
				"format": "dd.m.yyyy",
				"weekStart": 1,
				"autoclose": true
			});
			$('.form__add-on').click(function(){
				$(this).prevAll('.datepicker').datepicker('show');
			});
			// Hide datepicker on scroll and resize

			var dtPckr = $('.custom-datepicker');
			$(window).scroll(function() {
				dtPckr.datepicker('hide');
			});

			$(".custom-datepicker").click(function(){
				$(this).css('color','#34495e')
			});
		};
		if($('.visible-datepicker').length){
			var datepicker = $(".visible-datepicker").datepicker();
			datepicker.datepicker('show');
		};
	};

	this.initWysiwyg = function () {
		if($('#wysiwyg').length){
			$('#wysiwyg').ckeditor({
				removePlugins: 'elementspath'
			});
		}

	};
	this.initStripe = function () {
		if($(".jsStripe").length){
			$(".jsStripe li:nth-child(even)").addClass('even');
		}
	};

	this.initCarousel = function () {
		if($('.slider__holder').length){
			$(".slider__holder").carouFredSel({
				width: 620,
				height: "variable",
				items: {
					visible: 1,
					width: 620,
					height: "variable"
				},
				onCreate: function() {
					$(this).trigger("currentPosition", function( pos ) {
						var txt = (pos+1) + " из " + $("> *", this).length;
						$("#slider_log").html( txt );
					});
				},
				scroll: {
					pauseOnHover: true,
					onBefore : function() {
						$(this).trigger("currentPosition", function( pos ) {
							var txt = (pos+1) + " из " + $("> *", this).length;
							$("#slider_log").html( txt );
						});
					},
					onAfter : function() {
						$(this).trigger("currentPosition", function( pos ) {
							var txt = (pos+1) + " из " + $("> *", this).length;
							$("#slider_log").html( txt );
						});
					}
				},
				auto: {
					timeoutDuration: 5000,
					delay: 5000,
					progress: ".bar"
				},
				prev: ".slider__prev",
				next: ".slider__next"
			});
		};

		$('.gallery').each(function(){
			var gallery = $(".gallery__holder", $(this)),
				next = $(".gallery__next", $(this)),
				prev = $(".gallery__prev", $(this));

			gallery.carouFredSel({
				circular: true,
				infinite: false,
				auto 	: false,
				prev	: {
					button	: prev,
					key		: "left"
				},
				next	: {
					button	: next,
					key		: "right"
				}
			});
		})

	};

	this.initChoosen = function (){
		$(".chosen-select").chosen({max_selected_options: 3});
	};

	this.hasDrop = function (){
		if ($('.nav__drop_right').length) {
			$('.nav__drop_right').parent('.nav__drop-item').addClass('has-drop');
		}
	};
	this.initAccordion = function (){
		if ($('.accordion').length) {

			// Hide all contents except first
			$('.accordion__content').not('.active').css({
				height      : 0,
				overflow    : 'hidden'
			});

			$('.accordion__content.active').prev('.accordion__caption').addClass('active-link');

			// Do active first caption
//			$('.accordion__caption').first().addClass('active-link');

			$('.accordion__caption').click(function(){
				if ($(this).is('.active-link'))
				{
					$(this).next('.accordion__content').css('overflow', 'hidden').slideUp();
					$(this).removeClass('active-link');
				}
				else
				{
					$(this).next('.accordion__content').hide().css('height', 'auto').slideDown(function(){
						$(this).css('overflow', 'visible');
					});
					$(this).addClass('active-link');
				}
			});
		}
	};

	this.openPopup = function (){
		$('.jsOpenLink').click(function(e){
			var $thisId = $(this).attr('href');
			if($thisId.length) {
				if ($thisId =="#"){
					$('.jsOpenPopup').show();
				} else {
					$($thisId).show();
				}
			} else {
				$('.jsOpenPopup').show();
			}
			e.preventDefault();
		});
		$('.jsClosePopup').click(function(e){
			$('.jsOpenPopup').hide();
			e.preventDefault();
		});
	};

	this.TopScroll = function (){
		var currentScrollTop = 0;
		if($(document).scrollTop()> currentScrollTop){
			$('.top_scroll').fadeIn(1);
		}
		$(window).scroll(function(){

			currentScrollTop = $(window).scrollTop();

			if (currentScrollTop > 0){
				$('.top_scroll').fadeIn(1);
			}else{
				$('.top_scroll').fadeOut(1);

			}

			tempScrollTop = currentScrollTop;

		});

		$('.top_scroll').click(function(){
			if($.browser.safari){
				bodyelem = $("body")
			} else{
				if($.browser.opera){
					bodyelem = $("html")
				} else{
					bodyelem = $("html,body")
				}
			}

			bodyelem.animate({scrollTop: 0},700);

			return false;
		});
	};
	/*
	 this.RangeSlider = function (){
	 var sliderRangeItem = $("#filter-slider"),
	 sliderMin = $('.minCost'),
	 sliderMax = $('.maxCost'),
	 sliderMinStart = parseInt($('.filter__value-left').text()),
	 sliderMaxStart = parseInt($('.filter__value-right').text()),
	 sliderMinCur = sliderMinStart,
	 sliderMaxCur = sliderMaxStart;

	 sliderRangeItem.slider({
	 range: true,
	 step: 5000,
	 min: sliderMinStart,
	 max: sliderMaxStart,
	 values: [ sliderMinCur, sliderMaxCur ],
	 stop: function(event, ui) {
	 var event_ = document.createEvent("HTMLEvents");
	 event_.initEvent("change", true, true);
	 hiddenFieldMax[0].dispatchEvent(event_);
	 hiddenFieldMin[0].dispatchEvent(event_);
	 },
	 slide: function(event, ui){
	 sliderMinCur = ui.values[0];
	 sliderMaxCur = ui.values[1];
	 $('#filter-slider > .ui-slider-handle').first().children('.handle_value').html('РѕС‚ ' + sliderMinCur + ' <span class="b-rbl">a</span>');
	 $('#filter-slider > .ui-slider-handle').last().children('.handle_value').html('РґРѕ ' + sliderMaxCur + ' <span class="b-rbl">a</span>');

	 hiddenFieldMin.val(parseInt(sliderMinCur));
	 hiddenFieldMax.val(parseInt(sliderMaxCur));
	 }
	 });

	 $('#filter-slider > .ui-slider-handle').last().addClass('filter__item_last');
	 $('#filter-slider > .ui-slider-handle').first().children('.handle_value').html('РѕС‚ ' + sliderMinCur + ' <span class="b-rbl">a</span>');
	 $('#filter-slider > .ui-slider-handle').last().children('.handle_value').html('РґРѕ ' + sliderMaxCur + ' <span class="b-rbl">a</span>');
	 };*/

//	this.RangeSlider = function (){
//		var sliderRangeItem = $("#filter-slider"),
//			sliderMin = $('.minCost'),
//			sliderMax = $('.maxCost'),
//			sliderMinStart = parseInt($('.filter__value-left').text()),
//			sliderMaxStart = parseInt($('.filter__value-right').text()),
//			sliderMinCur = sliderMinStart,
//			sliderMaxCur = sliderMaxStart,
//			hiddenFieldMin = sliderRangeItem.siblings('input[type="hidden"].min-value'),
//			hiddenFieldMax = sliderRangeItem.siblings('input[type="hidden"].max-value');
//
//		sliderRangeItem.slider({
//			range: true,
//			min: sliderMinStart,
//			max: sliderMaxStart,
//			values: [ sliderMinStart, sliderMaxStart ],
//			stop: function(event, ui) {
//				updatetext(event, ui);
//				var event_ = document.createEvent("HTMLEvents");
//				event_.initEvent("change", true, true);
//				hiddenFieldMax[0].dispatchEvent(event_);
//				hiddenFieldMin[0].dispatchEvent(event_);
//				$('#filter-slider > .ui-slider-handle').first().children('.handle_value').html('от ' + sliderMinCur + ' <span class="b-rbl">a</span>' );
//				$('#filter-slider > .ui-slider-handle').last().children('.handle_value').html('до ' + sliderMaxCur + ' <span class="b-rbl">a</span>' );
//			},
//			slide: function(event, ui) {
//				updatetext(event, ui);
//				hiddenFieldMin.val(parseInt(sliderMinCur));
//				hiddenFieldMax.val(parseInt(sliderMaxCur));
//				$('#filter-slider > .ui-slider-handle').first().children('.handle_value').html('от ' + sliderMinCur + ' <span class="b-rbl">a</span>');
//				$('#filter-slider > .ui-slider-handle').last().children('.handle_value').html('до ' + sliderMaxCur + ' <span class="b-rbl">a</span>');
//			}
//		});
//		updatetext();
//            $('#filter-slider > .ui-slider-handle').last().addClass('filter__item_last');
//			$('#filter-slider > .ui-slider-handle').first().children('.handle_value').html('от ' + sliderMinCur + ' <span class="b-rbl">a</span>');
//			$('#filter-slider > .ui-slider-handle').last().children('.handle_value').html('до ' + sliderMaxCur + ' <span class="b-rbl">a</span>');
//
//		function updatetext(event, ui){
//			if (ui){
//				sliderMin.text(sliderRangeItem.slider("values",0));
//				sliderMax.text(sliderRangeItem.slider("values",1));
//				sliderMinCur = sliderRangeItem.slider("values",0);
//				sliderMaxCur = sliderRangeItem.slider("values",1);
//			}
//			$('#filter-slider > .ui-slider-handle').last().addClass('filter__item_last');
//			$('#filter-slider-left').html('от‚ ' + sliderMinCur + ' <span class="b-rbl">a</span>');
//			$('#filter-slider-right').html('до ' + sliderMaxCur + ' <span class="b-rbl">a</span>');
//		}
//	};

	this.RangeSlider = function (){
		var sliderRangeItem = $("#filter-slider"),
			sliderMin = $('.minCost'),
			sliderMax = $('.maxCost'),
			sliderMinStart = parseInt($('.filter__value-left').text()),
			sliderMaxStart = parseInt($('.filter__value-right').text()),
			sliderMinCur = sliderMinStart,
			sliderMaxCur = sliderMaxStart;

		sliderRangeItem.slider({
			range: true,
			min: sliderMinStart,
			max: sliderMaxStart,
			values: [ sliderMinStart, sliderMaxStart ],
			stop: function(event, ui) {
				sliderMin.text(sliderRangeItem.slider("values",0));
				sliderMax.text(sliderRangeItem.slider("values",1));
				sliderMinCur = sliderRangeItem.slider("values",0);
				sliderMaxCur = sliderRangeItem.slider("values",1);
				$('.filter__value-left').html(sliderMinCur + ' <span class="b-rbl">a</span>');
				$('.filter__value-right').html(sliderMaxCur + ' <span class="b-rbl">a</span>');
			},
			slide: function(event, ui){
				sliderMin.text(sliderRangeItem.slider("values",0));
				sliderMax.text(sliderRangeItem.slider("values",1));
				sliderMinCur = sliderRangeItem.slider("values",0);
				sliderMaxCur = sliderRangeItem.slider("values",1);
				$('.filter__value-left').html(sliderMinCur + ' <span class="b-rbl">a</span>');
				$('.filter__value-right').html(sliderMaxCur + ' <span class="b-rbl">a</span>');
			}
		});

//		$('#filter-slider > .ui-slider-handle').last().addClass('filter__item_last');
		$('.filter__value-left').html(sliderMinCur + ' <span class="b-rbl">a</span>');
		$('.filter__value-right').html(sliderMaxCur + ' <span class="b-rbl">a</span>');
	};

	this.initGallery = function (){
		if ($('#carousel').length) {
			//jCarousel Plugin
			$('#carousel').jcarousel({
				vertical: true,
				scroll: 1,
				auto: false,
				wrap: 'none',
				visible: 2
//                initCallback: mycarousel_initCallback
			});

			//Front page Carousel - Initial Setup
			$('.slideshow-carousel a img').css({'opacity': '0.5'});
			$('.slideshow-carousel a img:first').css({'opacity': '1.0'});
			$('.slideshow-carousel li a:first').append('<span class="arrow"></span>');


			//Combine jCarousel with Image Display
			$('.slideshow-carousel li a').hover(
				function () {

					if (!$(this).has('span').length) {
						$('.slideshow-carousel li a img').stop(true, true).css({'opacity': '0.5'});
						$(this).stop(true, true).children('img').css({'opacity': '1.0'});
					}
				},
				function () {

					$('.slideshow-carousel li a img').stop(true, true).css({'opacity': '0.5'});
					$('.slideshow-carousel li a').each(function () {

						if ($(this).has('span').length) $(this).children('img').css({'opacity': '1.0'});

					});

				}
			).click(function () {

					$('span.arrow').remove();
					$(this).append('<span class="arrow"></span>');
					$('.slideshow-main li').removeClass('active');
					$('.slideshow-main li.' + $(this).attr('rel')).addClass('active');

					return false;
				});
//Carousel Tweaking
		};
		if ($('#carousel-h').length) {
			//jCarousel Plugin
			$('#carousel-h').jcarousel({
				scroll: 1,
				auto: false,
				wrap: 'none',
				visible: 2,
				initCallback: mycarousel_initCallback
			});

			//Front page Carousel - Initial Setup
			$('.slideshow-carousel a img').css({'opacity': '0.5'});
			$('.slideshow-carousel a img:first').css({'opacity': '1.0'});
			$('.slideshow-carousel li a:first').append('<span class="arrow"></span>')


			//Combine jCarousel with Image Display
			$('.slideshow-carousel li a').hover(
				function () {

					if (!$(this).has('span').length) {
						$('.slideshow-carousel li a img').stop(true, true).css({'opacity': '0.5'});
						$(this).stop(true, true).children('img').css({'opacity': '1.0'});
					}
				},
				function () {

					$('.slideshow-carousel li a img').stop(true, true).css({'opacity': '0.5'});
					$('.slideshow-carousel li a').each(function () {

						if ($(this).has('span').length) $(this).children('img').css({'opacity': '1.0'});

					});

				}
			).click(function () {

					$('span.arrow').remove();
					$(this).append('<span class="arrow"></span>');
					$('.slideshow-main li').removeClass('active');
					$('.slideshow-main li.' + $(this).attr('rel')).addClass('active');

					return false;
				});
//Carousel Tweaking

			function mycarousel_initCallback(carousel) {

				// Pause autoscrolling if the user moves with the cursor over the clip.
				carousel.clip.hover(function() {
					carousel.stopAuto();
				}, function() {
					carousel.startAuto();
				});
			}
		}
	};

	this.initSelect = function (){
		if ($('.filter__select').length){

			$('.filter__select').each(function(i, v){
				var topBlock = $('.filter__top', this),
					arrow = $('.ico_type_arrow', this),
					listBlock = $('.filter__list-block', this),
					listItems = $('.filter__list', this);

				topBlock.click(function(e){
					arrow.toggleClass('open');
					listBlock.slideToggle();
					e.stopPropagation();
					e.preventDefault();
				});
				$(document).click(function(e){
					listBlock.slideUp();
					arrow.removeClass('open');
					//e.preventDefault();
				});

				listItems.not('.filter__list_fst').click(function(e){
					var $this = $(this);
					if ($this.hasClass('filter__list_dsbl')){
						return false;
					}

					var tlist = $this.text();
					listItems.removeClass('active');
					$(this).toggleClass('active');

					if (listItems.hasClass('active')){
						listItems.eq(0).text(tlist);
						listBlock.slideUp();
						arrow.removeClass('open');
						$(this).toggleClass('open');
					}



					e.stopPropagation();
					e.preventDefault();
				});
			});
		}
	};


	this.initViewMore = function (){
		if ($('.jsMoreText').length){
			var $text = $('.jsMoreText');

				$text.each(function(){
					var $this = $(this),
						$textBox = $this.find('.jsMoreTextBox'),
						$opener = $this.find('.jsMoreTextOpener'),
						$textBoxHeight = $textBox.height();

						if($textBox.height()>100) {
							$textBox.css({
								'height': '100px',
								'overflow': 'hidden'
							});
							$opener.click(function(e){
								$textBox.animate({
									'height': $textBoxHeight,
									'overflow': 'auto'
								}, 300);
								$(this).fadeOut();
								e.preventDefault();
							});
						} else {
							$textBox.css({
								'height': 'auto',
								'overflow': 'auto'
							});
							$opener.hide();
						}
				});
		}
	};

	this.initBtnChangeText = function (){
		if ($('.jsBtnChangeText').length){
			var $btn = $('.jsBtnChangeText');

			$btn.each(function(){
				var $this = $(this),
					$btnOldText = $this.children('.btn__inner').text(),
					$btnNewText = $this.attr('data-text');

				$this.click (function(e){
					if ($(this).text() != $btnNewText) {
						$this.children('.btn__inner').text($btnNewText);
						$this.removeClass('btn_green');
						$this.addClass('btn_unsubscribe');
					} else {
						$this.children('.btn__inner').text($btnOldText);
						$this.addClass('btn_green');
						$this.removeClass('btn_unsubscribe');
					}
					e.preventDefault();
				});
			});
		}
	};

	this.initPopupImage = function (){
		if ($('.popup__img').length){
			var $imgBox = $('.popup__img'),
				$image = $('.popup__img > img');

			$image.attr('src', $image.attr('src') + "?" + new Date().getTime());
			$image.load(function(){
				var $this=$(this);
				if ($this.width() >= 600) {
					$this.css({
						display:'block'
					});
					$this.attr('width','600');
				} else {
					$imgBox.css({
						'padding-top':'20px',
						'padding-bottom':'20px',
						'text-align':'center'
					})
				}
			})
		}
	};

	this.initPopupVideo = function (){
		if ($('.popup__video').length){
			var $videoBox = $('.popup__video'),
				$video = $('.popup__video > iframe');
			console.log($video.width());
			if ($video.width() >= 720) {
				$video.css({
					width:'720px',
					height:'405px'
				});
			} else {
				$videoBox.css({
					'padding-top':'20px',
					'padding-bottom':'20px',
					'text-align':'center'
				})
			}
		}
	};


    this.initSelect2 = function (){
        if ($('.select_custom').length) {
            $("select").select2({ minimumResultsForSearch: -1 });

            $(document).on("select2-open", "select", function () {
                var el;
                $('.select2-results').each(function () {
                    var api = $(this).data('jsp');

                    if (api !== undefined) api.destroy();
                });

                $('.select2-results').each(function () {
                    if ($(this).parent().css("display") != 'none') el = $(this);

                    if (el === undefined) return;

                    el.mCustomScrollbar({
                    /*    autoScrollOnFocus: true,*/

                        mouseWheel:true,
                        advanced:{
                            updateOnContentResize: true,

                        }
                    });
                });
            });
        }
    };
	$(function(){
		scope.customDatepicker();
		scope.initWysiwyg();
		scope.initCarousel();
		scope.hasDrop();
		scope.initGallery();
		scope.initChoosen();
		scope.openPopup();
		scope.initStripe();
		scope.initAccordion();
		scope.RangeSlider();
		scope.TopScroll();
		scope.initSelect();
		scope.initViewMore();
		scope.initBtnChangeText();
		scope.initPopupImage();
		scope.initPopupVideo();
        scope.initSelect2();
	});

};


var mainJs = new MainJsClass();

function mycarousel_initCallback(carousel) {

	// Pause autoscrolling if the user moves with the cursor over the clip.
	carousel.clip.hover(function() {
		carousel.stopAuto();
	}, function() {
		carousel.startAuto();
	});
}